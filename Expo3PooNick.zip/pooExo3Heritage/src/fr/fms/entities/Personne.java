package fr.fms.entities;

public class Personne {
	private String firstName;
	private String lastName;
	private int age;
	private String currentCity;
	
	
	public Personne(String firstName, String lastName,int age,String currentCity) {
		setFirstName(firstName);
		setLastName(lastName);
		setAge(age);
		setCurrentCity(currentCity);
	
	
		}


	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}


	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}


	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}


	/**
	 * @return the currentCity
	 */
	public String getCurrentCity() {
		return currentCity;
	}


	/**
	 * @param currentCity the currentCity to set
	 */
	public void setCurrentCity(String currentCity) {
		this.currentCity = currentCity;
	}


	@Override
	public String toString() {
		return "Personne [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", currentCity="
				+ currentCity + "]";
	}


	
	
}



