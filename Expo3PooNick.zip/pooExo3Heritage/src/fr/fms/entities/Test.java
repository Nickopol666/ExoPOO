package fr.fms.entities;

public class Test {
	public static void main(String [] args) {
		Capitale paris = new Capitale("Paris","France",2000000,"Tour Eiffel");
		Capitale london=new Capitale("London","United Kingdom",1900000,"Big Ben");
	
	
		
	System.out.println(paris);
	System.out.println(london);
	}

}
