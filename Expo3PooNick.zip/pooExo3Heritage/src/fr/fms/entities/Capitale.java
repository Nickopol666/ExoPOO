package fr.fms.entities;

public class Capitale extends City{
	private String cityName;
	private String Monument;
	
	
	
	
	public Capitale(String cityName,String country,int crowd,String monument) {
		super(country,crowd);
		setCityName(cityName);
		setMonument(monument);
		
	}




	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}




	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}




	/**
	 * @return the monument
	 */
	public String getMonument() {
		return Monument;
	}




	/**
	 * @param monument the monument to set
	 */
	public void setMonument(String monument) {
		Monument = monument;
	}


	
}
