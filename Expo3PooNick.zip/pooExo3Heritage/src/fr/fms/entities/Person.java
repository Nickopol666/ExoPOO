
public class Person  {
	private  String name;
	private  String surname;
	private  int age;
	private  String adress;
	private  City bornCity;

	
	public Person(String name,String surname,int age,String adress,City bornCity) {
		setName(name);
		setSurname(surname);
		setAge(age);
		setAdress(adress);
		setBornCity(bornCity);
	}
	public Person(String name,String surname,int age,String adress) {
		setName(name);
		setSurname(surname);
		setAge(age);
		setAdress(adress);
	}
	public Person (String name,String surname,int age){
		setName(name);
		setSurname(surname);
		setAge(age);
		setAdress("unknown");
	}
	public Person (String name,String surname) {
		setName(name);
		setSurname(surname);
		setAdress("unknown");
	}

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getSurname() {
		return surname;
	}



	public void setSurname(String surname) {
		this.surname = surname;
	}



	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public String getAdress() {
		return adress;
	}



	public void setAdress(String adress) {
		this.adress = adress;
	}

	public City getBornCity() {
		return bornCity;
	}
	public void setBornCity(City bornCity) {
		this.bornCity = bornCity;
	}
	@Override
	public String toString() {
		return  name  +"," + surname +"," + age+"ans" + ",habitant " + adress + ",Ville de naissance :"
				+ bornCity ;
	}

}
