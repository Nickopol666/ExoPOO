package fr.fms.entities;

public class City {
	private String country;
	private int crowd;

	
	public City(String country,int crowd) {
		setCountry(country);
		setCrowd(crowd);
	}


	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}


	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}


	/**
	 * @return the crowd
	 */
	public int getCrowd() {
		return crowd;
	}


	/**
	 * @param crowd the crowd to set
	 */
	public void setCrowd(int crowd) {
		this.crowd = crowd;
	}


	@Override
	public String toString() {
		return "City [country=" + country + ", crowd=" + crowd + "]";
	}


	
}
