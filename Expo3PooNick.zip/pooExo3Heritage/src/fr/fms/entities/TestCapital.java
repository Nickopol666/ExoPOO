package fr.fms.entities;

public class TestCapital {
	
	public static void main(String [] args) {
		
	}
}
