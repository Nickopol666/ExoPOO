package fr.fms.entities;

public class Employé extends Person{
	private String company;
	private double salary;
	
	public Employé(String company,double salary,String firstName,String lastName,int age,String adress,City bornCity) {
		super(firstName,lastName,age,adress,bornCity);
		setCompany(company);
		setSalary(salary);	
	}

	/**
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}

	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "[  "+ super.toString() +"Employé [company=" + company + ", salary=" + salary + "]";
	}
	
	
	
	
}
